Sciter MFC integration demo. 

Class CSciterChildView uses  "mix-in" type of embedding. See: http://sciter.com/developers/embedding-principles/