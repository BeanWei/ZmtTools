//
//  AppDelegate.h
//  ulayered
//
//  Created by Andrew Fedoniouk on 2014-12-28.
//  Copyright (c) 2014 Andrew Fedoniouk. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end

