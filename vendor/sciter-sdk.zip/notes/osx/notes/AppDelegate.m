//
//  AppDelegate.m
//  notes
//
//  Created by Andrew Fedoniouk on 2017-08-01.
//  Copyright © 2017 Andrew Fedoniouk. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}


@end
