
spctl -a -t install --verbose --verbose --context context:primary-signature -v ../distributions/sciter-notes-setup.dmg