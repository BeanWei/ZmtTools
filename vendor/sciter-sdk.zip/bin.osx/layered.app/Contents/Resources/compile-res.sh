#!/bin/sh

echo "compiling!"
../../bin.osx/packfolder ./resources.cpp ./res/ layered
